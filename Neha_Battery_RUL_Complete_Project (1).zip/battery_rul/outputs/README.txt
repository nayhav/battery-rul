Each run writes to a new empty directory. Choose a different --output for reruns.
report.html is the entry point; figures, metrics and artifacts live alongside it.
Bundled verified_demo is SYNTHETIC and cannot support claims about NASA performance.
