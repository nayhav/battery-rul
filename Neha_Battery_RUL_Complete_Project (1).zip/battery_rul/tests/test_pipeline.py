"""Regression checks for scientific validity, not just implementation details."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
import numpy as np
import pandas as pd
from scipy.io import savemat
from battery_rul.data import make_demo, construct_targets, parse_mat, validate_frame, FULL_FEATURES
from battery_rul.features import WindowPreprocessor, make_windows
from battery_rul.experiment import run_experiments, predict_history
from battery_rul.models import LSTMRegressor, create_model

class ScientificIntegrityTests(unittest.TestCase):
    def test_first_crossing_not_last_record(self):
        frame = pd.DataFrame({'battery_id':['A']*5,'cycle':[1,2,3,4,5],
                              'capacity_ah':[2,1.6,1.39,1.5,1.3]})
        labelled,audit=construct_targets(frame)
        self.assertEqual(labelled.rul.tolist(),[2,1,0])
        self.assertEqual(audit.eol_cycle.iloc[0],3)
        self.assertEqual(audit.excluded_after_eol.iloc[0],2)

    def test_non_crossing_is_censored(self):
        labelled,audit=construct_targets(make_demo())
        self.assertTrue(audit.set_index('battery_id').loc['SIM03','censored'])
        self.assertNotIn('SIM03',labelled.battery_id.unique())

    def test_missing_capacity_does_not_renumber(self):
        frame=pd.DataFrame({'battery_id':['A']*4,'cycle':[1,2,3,4],
                            'capacity_ah':[2,np.nan,1.5,1.39]})
        labelled,_=construct_targets(frame)
        self.assertEqual(labelled.rul.tolist(),[3,2,1,0])

    def test_common_endpoints_and_no_cross_cell_windows(self):
        frame,_=construct_targets(make_demo())
        x10,m10=make_windows(frame,['cycle'],10,30)
        x30,m30=make_windows(frame,['cycle'],30,30)
        pd.testing.assert_frame_equal(m10,m30)
        np.testing.assert_array_equal(x10[:,-1,0],m10.cycle)
        np.testing.assert_array_equal(x30[:,0,0],m30.cycle-29)

    def test_future_changes_leave_past_features_unchanged(self):
        frame=make_demo().query("battery_id == 'SIM01'").copy()
        x,m=make_windows(frame,FULL_FEATURES,10)
        changed=frame.copy()
        changed.loc[changed.cycle>50,'voltage_mean']=9999
        y,n=make_windows(changed,FULL_FEATURES,10)
        np.testing.assert_allclose(x[m.cycle<=50],y[n.cycle<=50],equal_nan=True)

    def test_preprocessing_not_refitted_on_holdout(self):
        train=np.array([[[1,np.nan,5],[3,np.nan,5]],[[4,np.nan,5],[6,np.nan,5]]],dtype=float)
        pre=WindowPreprocessor().fit(train)
        mean=pre.scaler.mean_.copy()
        pre.transform(np.array([[[1000,99,2],[2000,99,2]]],dtype=float))
        np.testing.assert_array_equal(mean,pre.scaler.mean_)
        self.assertEqual(pre.keep.tolist(),[True,False,False])

    def test_duplicate_and_gapped_cycles_rejected(self):
        frame=make_demo().iloc[:4].copy()
        with self.assertRaises(ValueError): validate_frame(pd.concat([frame,frame]))
        with self.assertRaises(ValueError): validate_frame(frame.iloc[[0,2,3]])

    def test_real_mat_structure_and_past_only_eis(self):
        discharge=lambda capacity: {'type':'discharge','data':{
            'Capacity':capacity,'Time':np.array([0,100]),'Voltage_measured':np.array([4.1,2.7]),
            'Current_measured':np.array([-2,-2]),'Temperature_measured':np.array([25,29])}}
        operations=[discharge(1.9),{'type':'impedance','data':{'Re':.04,'Rct':.07}},
                    {'type':'charge','data':{'Time':np.array([0,300]),'Voltage_measured':np.array([3,4.2])}},
                    discharge(1.8)]
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'B0005.mat'
            savemat(path,{'B0005':{'cycle':np.array(operations,dtype=object)}})
            result=parse_mat(path)
        self.assertTrue(np.isnan(result.re_ohm.iloc[0]))
        self.assertEqual(result.re_ohm.iloc[1],.04)
        self.assertEqual(result.charge_duration_s.iloc[1],300)
        self.assertEqual(result.eis_age_cycles.iloc[1],1)

    def test_end_to_end_artifact_prediction_without_labels(self):
        frame=make_demo()
        with tempfile.TemporaryDirectory() as tmp:
            run_experiments(frame,tmp,windows=(10,),feature_sets=('full',),
                            models=('ridge',),fast=True,do_shap=False)
            artifact=next((Path(tmp)/'models').glob('*SIM01.joblib'))
            result=predict_history(artifact,frame.query("battery_id=='SIM01'").iloc[:50])
            self.assertGreaterEqual(result['predicted_rul_cycles'],0)
            self.assertFalse(result['seen_training_cell'])
            self.assertTrue((Path(tmp)/'report.html').is_file())
            with self.assertRaises(FileExistsError):
                run_experiments(frame,tmp,do_shap=False,models=('ridge',))

    @unittest.skipUnless(importlib.util.find_spec('torch'),'torch not installed')
    def test_lstm_fit_predict(self):
        x=np.random.default_rng(0).normal(size=(12,10,3)).astype(np.float32)
        model=LSTMRegressor(epochs=2,hidden_size=4).fit(x,np.arange(12,dtype=float))
        self.assertEqual(model.predict(x).shape,(12,))
        self.assertTrue(np.isfinite(model.predict(x)).all())

    @unittest.skipUnless(importlib.util.find_spec('xgboost'),'xgboost not installed')
    def test_xgb_fit_predict(self):
        x=np.arange(40,dtype=float).reshape(20,2)
        model=create_model('xgb',{'n_estimators':3,'max_depth':2},42).fit(x,np.arange(20))
        self.assertTrue(np.isfinite(model.predict(x)).all())

    @unittest.skipUnless(importlib.util.find_spec('shap'),'shap not installed')
    def test_shap_additivity(self):
        import shap
        x=np.arange(40,dtype=float).reshape(20,2)
        model=create_model('rf',{'n_estimators':5,'max_depth':2},42).fit(x,np.arange(20))
        result=shap.TreeExplainer(model,data=x)(x[:3])
        np.testing.assert_allclose(result.values.sum(axis=1)+result.base_values,model.predict(x[:3]),atol=1e-5)

if __name__=='__main__':
    unittest.main()
