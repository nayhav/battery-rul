"""Regenerate a standalone, readable notebook from the tested Python modules."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
cells = []
def markdown(text):
    cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(keepends=True)})
def code(text):
    cells.append({'cell_type':'code','metadata':{},'execution_count':None,'outputs':[],
                  'source':text.splitlines(keepends=True)})

markdown('''# Lithium-ion battery remaining useful life prediction
**Neha Varadharajan · 240962214 · CSE AIML · ML Mini Project**

This standalone notebook implements the complete proposed workflow: NASA ingestion,
causal cycle features, 10/20/30-cycle histories, nested battery-level validation,
Random Forest, XGBoost, LSTM, and SHAP. It includes all implementation code below.

**Default: SYNTHETIC core demonstration, not NASA findings.** Switch to NASA mode
and full backends for the assignment experiment. Supplied outputs validate software only.
Prediction time is after a completed discharge. RUL is the number of future discharge
cycles to the first observed capacity ≤ 1.4 Ah. Non-crossing cells are censored, not
assigned the last recorded cycle as EOL.

## 1. Environment and configuration
Use Python 3.11/3.12. In the project, install `requirements-full.txt` and choose that
virtual environment as the notebook kernel. For the standalone notebook, install:
`numpy==2.3.5 pandas==2.2.3 scipy==1.17.0 scikit-learn==1.8.0 matplotlib==3.10.8 joblib==1.5.3`.
For the full experiment also install `xgboost>=3.0,<4`, `torch>=2.6,<3`,
`shap>=0.48,<0.51`, `jupyterlab` and `ipykernel`.

No package installation or download runs implicitly. Full mode fails clearly if a
requested dependency is missing. The project ZIP also includes a NASA downloader.
''')
code('''from pathlib import Path
from datetime import datetime
import sys

MODE = "demo"              # "demo" or "nasa"
FULL_MODELS = False         # True enables RF + XGBoost + LSTM + SHAP
WINDOWS = (10, 20, 30)
FEATURE_SET_NAMES = ("full", "reduced")  # Add "capacity_only" for a control
SEEDS = (42,)               # e.g. (7, 42, 123) for the final robustness study
THRESHOLD_AH = 1.4
ROOT = Path.cwd()
if ROOT.name == "notebooks":
    ROOT = ROOT.parent
RAW_DIR = ROOT / "data" / "raw"          # edit for a standalone NASA run
OUTPUT_DIR = ROOT / "outputs" / ("notebook_" + MODE + "_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
assert MODE in ("demo", "nasa")
print("Python:", sys.version.split()[0], "| source:", MODE, "| full models:", FULL_MODELS)
print("Output directory:", OUTPUT_DIR)
''')
sections=[('data','2. Data ingestion and target construction',
'''Raw MATLAB operation order is preserved. Only earlier charge/EIS measurements
are joined to the current discharge. Each discharge increments the cycle counter,
even if capacity is missing. The target constructor separately audits observed EOL.
The demo deliberately includes a non-crossing cell.'''),
('features','3. Past-only windows and training-only transforms',
'''Every history ends at the prediction cycle. All tested window lengths share
endpoints starting at cycle 30. Medians, scaling and variance filtering are refitted
within each training split; no statistics are learned from the held-out cell.'''),
('models','4. Models and declared search grids',
'''RF/XGBoost consume last/mean/std/slope window summaries. LSTM consumes the full
sequence. The cycle reference uses only mean training-cell lifetime. LSTM epochs and
hidden size are selected by inner cell validation, never by outer-test early stopping.'''),
('reporting','5. Reproducible figures and report',
'''The report distinguishes synthetic from measured data. It includes capacity,
model comparison, ablation and prediction/residual figures, plus CSV tables.'''),
('experiment','6. Nested cell evaluation and explanations',
'''For each outer test cell, tune using only remaining cells, refit on those cells,
and score the untouched test cell. SHAP uses training-background data and held-out
examples. The tree to explain is selected with inner validation, not test error.''')]
for name,title,description in sections:
    markdown('## '+title+'\n\n'+description)
    source=(ROOT/'battery_rul'/f'{name}.py').read_text(encoding='utf-8')
    # All definitions now live in notebook scope, so relative package imports vanish.
    source=re.sub(r'^\s*from \.\w+ import [^\n]+\n','',source,flags=re.MULTILINE)
    code(source)
markdown('''## 7. Load and audit data
NASA mode reads all four original MATLAB files from RAW_DIR. Download from
[NASA PCoE](https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/).
Cite B. Saha and K. Goebel (2007), Battery Data Set, NASA Ames PCoE.

If a cell does not reach 1.4 Ah, it has no exact supervised RUL label. A reduced count
of scored folds is an honest result; never relabel the last observation as failure.''')
code('''if MODE == "demo":
    cycle_data = make_demo(seed=42)
else:
    cycle_data = extract_nasa(RAW_DIR, ROOT / "data" / "processed" / "nasa_cycles.csv")
labelled_data, eol_audit = construct_targets(cycle_data, THRESHOLD_AH)
print(eol_audit.to_string(index=False))
print("\\nMissing fractions:\\n", cycle_data[FULL_FEATURES].isna().mean().round(3).to_string())
print("\\nObserved-EOL cells:", labelled_data.battery_id.nunique())
assert labelled_data.battery_id.nunique() >= 3, "Nested evaluation needs at least three observed-EOL cells."
''')
markdown('''## 8. Execute the experiment
Full NASA mode can take time on CPU. The demo uses a small grid; it is not a scientific
performance comparison. Missing optional backends are never silently replaced.''')
code('''selected_models = ("rf", "xgb", "lstm") if FULL_MODELS else ("rf", "ridge")
summary_table = run_experiments(
    cycle_data, OUTPUT_DIR, windows=WINDOWS, feature_sets=FEATURE_SET_NAMES,
    models=selected_models, seeds=SEEDS, threshold=THRESHOLD_AH,
    fast=(MODE == "demo"), do_shap=FULL_MODELS,
)
print(summary_table.round(3).to_string(index=False))
''')
markdown('''## 9. Visualize held-out predictions and ablations
Each curve comes from a battery excluded from training. The comparison plot uses a
predeclared window, not a post-hoc best test configuration. Error = prediction − truth;
positive values indicate overoptimistic remaining life.''')
code('''# In a Jupyter kernel, display the saved report figures inline.
RENDERED_IMAGES = []
def show_image(path):
    try:
        from IPython.display import display, Image
        display(Image(filename=str(path)))
    except ImportError:
        # Enables the identical code cells to run as ordinary Python, too.
        RENDERED_IMAGES.append(str(path))
        print("Saved figure:", path)

for filename in ("capacity.png", "model_comparison.png", "ablations.png", "predictions.png"):
    show_image(OUTPUT_DIR / "figures" / filename)
print("Open HTML report:", OUTPUT_DIR / "report.html")
''')
markdown('''## 10. Examine cell heterogeneity and explanation outputs
Macro-averages give batteries equal weight. Between-cell spread is not a confidence
interval, and overlapping windows are not independent experiments. Check negative R²,
near-EOL overestimation, and feature sensitivity. SHAP is associational, not causal.''')
code('''cell_metrics = pd.read_csv(OUTPUT_DIR / "metrics_by_cell.csv")
print(cell_metrics.groupby(["model", "test_battery"])[["mae", "rmse", "bias"]].mean().round(3).to_string())
print("\\nInner-selected tree performance:")
print(pd.read_csv(OUTPUT_DIR / "inner_selected_tree_metrics.csv").round(3).to_string(index=False))
if FULL_MODELS:
    for figure in sorted((OUTPUT_DIR / "shap").glob("*/shap_summary.png")):
        show_image(figure)
else:
    print("SHAP explicitly disabled in core demo; enable FULL_MODELS after installing full dependencies.")
''')
markdown('''## 11. Inference from a partial history
Use the matching outer-held-out model. No RUL column, future capacity or known lifetime
is required. This demonstrates artifact round-trip and deployment preprocessing.''')
code('''example_cell = sorted(labelled_data.battery_id.unique())[0]
example_window = WINDOWS[0]
example_features = FEATURE_SET_NAMES[0]
artifact = OUTPUT_DIR / "models" / f"rf_{example_features}_w{example_window}_seed{SEEDS[0]}_{example_cell}.joblib"
partial_history = cycle_data[cycle_data.battery_id == example_cell].iloc[:max(WINDOWS)+10].copy()
print(predict_history(artifact, partial_history))
''')
markdown('''## 12. What to conclude — after the real-data run

1. Report the EOL audit and explain any censored cell exclusion.
2. Compare MAE/RMSE per battery and macro-average across batteries. Which cell is hard?
3. Does a longer window help consistently, or only on one battery?
4. Does removing capacity/durations change generalization? Discuss remaining proxies.
5. Does LSTM justify its complexity on this small dataset? Poorer performance is valid.
6. Explain SHAP's leading sensors, correlations and limitations without causal claims.
7. Preserve config, versions, input hashes and all outer predictions for reproducibility.

Do not copy synthetic scores into the NASA results section. A low post-hoc test error
is not proof of broad generalization. Only a few independent batteries are observed;
future work should add external cells, censored-target models and calibrated uncertainty.

### Reference links
- [NASA dataset catalog](https://data.nasa.gov/dataset/li-ion-battery-aging-datasets)
- [PyTorch LSTM](https://docs.pytorch.org/docs/stable/generated/torch.nn.LSTM.html)
- [XGBoost API](https://xgboost.readthedocs.io/en/stable/python/python_api.html)
- [SHAP TreeExplainer](https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html)

### Verification note
The supplied default code cells were executed sequentially in a clean Python process.
A Jupyter kernel/UI and the optional full backends were unavailable in the build environment.
The notebook's full NASA configuration still needs execution on your computer.
''')
for i,cell in enumerate(cells):
    cell['id']=f'cell-{i:03d}'
nb={'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
    'language_info':{'name':'python','version':'3.11'}},'cells':cells}
path=ROOT/'notebooks'/'Battery_RUL_Complete.ipynb'
path.write_text(json.dumps(nb,indent=1,ensure_ascii=False),encoding='utf-8')
print(path)
