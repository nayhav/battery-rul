Place the original B0005.mat, B0006.mat, B0007.mat, B0018.mat here.
Alternatively run: python -m battery_rul download
No measured NASA data are bundled. See docs/DATA_CARD.md for provenance.
