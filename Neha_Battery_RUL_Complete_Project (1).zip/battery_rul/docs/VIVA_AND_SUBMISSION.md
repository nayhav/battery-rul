# Submission and viva guide

## Proposal-to-implementation map

| Proposal objective | Implementation / evidence |
|---|---|
| NASA multivariate degradation data | `data.py`: original MATLAB parser, causal charge/EIS joins, provenance hashes |
| Cycle-based reference | `CycleBaseline`: training-cell mean lifetime minus current cycle |
| RF / XGBoost / LSTM comparison | `models.py`, common outer folds in `experiment.py` |
| 10 / 20 / 30 history windows | `make_windows`; identical evaluated endpoints for fair comparison |
| Full / reduced health indicators | `FEATURE_SETS`; reduced removes capacity and both durations |
| Battery-level holdout | Outer LOBO with inner battery-separated parameter selection |
| RUL at 1.4 Ah | `construct_targets`; first threshold crossing and explicit censoring audit |
| SHAP interpretation | Best tree selected by inner validation; training background, held-out explanations |
| MAE / RMSE / R² / cycle errors | Per-cell and macro results, figures, HTML report, stage diagnostics |
| Reproducibility | Seeds, declared grids, environment versions, saved inputs, hashes, regression tests |
| VS Code and notebook | CLI/F5 configuration plus readable standalone equivalent notebook |

## Suggested final report structure

1. **Abstract:** task, source, label definition, evaluated cells, validation protocol,
   principal measured result and one key limitation. Fill in actual NASA findings only.
2. **Problem and motivation:** RUL vs SOH, completed-discharge prediction time, why cell
   heterogeneity matters. Avoid claiming deployment safety from this tiny benchmark.
3. **Data audit:** table from `eol_audit.csv`, capacity curves, missingness, exclusion
   reasons, observed endpoints. State the number of independent batteries.
4. **Method:** feature dictionary, temporal summaries vs sequences, reduced set,
   preprocessing, model grids, nested battery splits, formulas for metrics.
5. **Results:** per-cell errors first, macro metrics second; feature/history ablations,
   seeds, early/late life errors and plots. Report failures as well as strengths.
6. **Interpretability:** inner-selected tree SHAP plot and sensor-level discussion;
   mention correlated features and after-discharge capacity access.
7. **Discussion:** overfitting, small sample size, censoring selection bias, operating
   protocol differences, compute cost, learning vs simple cycle baseline.
8. **Conclusion and future work:** answer the three objectives with measured evidence;
   add external cells, survival-aware targets and uncertainty calibration as next steps.
9. **Reproducibility appendix:** source citation, file hashes, package versions, config,
   test results and exact command. Verify bibliography entries individually.

## Five-minute demonstration

- Show the README and data source; explain the threshold and censoring audit.
- Open capacity plots. Explain why the last record is not automatically failure.
- Show the full NASA report and per-cell predictions; distinguish it from the demo.
- Explain the train/inner-validation/outer-test battery split in plain language.
- Compare windows and full/reduced sensors. Show SHAP from the inner-selected tree.
- Run saved-model inference using only a partial history, then show the tests.

## Questions you should be able to answer

**Why not randomly split cycles?** Adjacent windows from the same battery are strongly
correlated. Random splitting lets training see almost the same degradation trajectory
as testing and measures within-cell interpolation rather than unseen-cell generalization.

**Is capacity leakage?** Not at our stated prediction time: it is measured after the
current discharge. Future capacity or final lifetime would be leakage. The reduced set
checks dependence on direct capacity/duration indicators, but it cannot remove every proxy.

**How are LSTM inputs shaped?** Number of windows × history length × retained features.
The final hidden sequence output predicts one scalar RUL for the endpoint, not one value
per timestep. The LSTM is unidirectional.

**Why might RF beat LSTM?** Only a few independent trajectories are available. The LSTM
has more parameters and may overfit. A complex architecture is not evidence of superiority.

**Why can R² be negative?** Its squared errors exceed those of predicting the held-out
cell's true target mean. The true mean is a scoring reference, not an available predictor.

**Why compare at cycle 30 onward?** Otherwise the 10-cycle model would be evaluated on
earlier-life cases that the 30-cycle model cannot predict, confounding model/history effects.

**What if a battery does not cross 1.4 Ah?** Its exact EOL and RUL are not observed. We
flag it as censored and do not invent labels; the reported regression scope excludes it.

**How is the best model chosen?** Hyperparameters are chosen with inner battery folds.
The tree chosen for each outer fold's explanation is also selected by inner scores.
Looking at all outer errors and reporting the smallest as an unbiased deployable winner
would introduce selection bias.

**Why not report tight confidence intervals?** Hundreds of overlapping windows do not
create hundreds of independent batteries. Three/four cells cannot support a precise
population-generalization claim. Seeds describe algorithmic variation, not cell diversity.

**Does SHAP prove a physical mechanism?** No. It decomposes model predictions relative
to a background under feature-dependence assumptions; correlated variables complicate
attribution. A causal intervention claim needs more than a predictive explanation.

**Is the synthetic demo a result?** It is an execution result and test fixture, not
empirical evidence for NASA batteries. Its degradation relationships were specified in code.

## Before submitting

- Run all requested models on actual NASA data and keep `run_status.json` with status complete.
- Run the tests with full dependencies; investigate failures instead of ignoring them.
- Replace any discussion placeholders with results you actually generated and understood.
- Include the number of scored cells and why others were censored.
- Ensure every figure identifies the source and whether it is a demo.
- Check that the notebook uses the intended kernel and is rerun in NASA mode if submitted as results.
- Keep the source citation and acknowledge assistance according to your course policy.
