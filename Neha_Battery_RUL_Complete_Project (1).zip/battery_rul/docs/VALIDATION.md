# Verification record — 2026-10-08

## Successfully executed in the build environment

- Python compilation of every package module, test and notebook builder.
- 12 scientific-integrity tests discovered: **9 passed, 3 skipped** because their
  optional dependencies were absent. No test failed.
- Tests cover first-crossing EOL, censoring, missing-capacity cycle preservation,
  identical endpoints across history lengths, causal windows, train-only preprocessing,
  duplicate/gapped input rejection, a real SciPy-written MATLAB struct parsing fixture,
  and end-to-end model persistence/inference/reporting.
- Full core demo: 3 observed-EOL synthetic cells × 3 history windows × 2 feature sets,
  with RF, Ridge and the cycle baseline, including inner cell splits.
- All **11 notebook code cells** executed sequentially in a fresh Python process.
  Genuine printed outputs and generated figures are preserved in the notebook.
- Notebook and package summary metrics agree within **1e-10** on the same demo.
- CLI artifact inference on the first 50 cycles of held-out SIM01 succeeded and
  reported `seen_training_cell: false`.
- Saved prediction/error figure visually inspected; axes, legends and panels readable.

## Explicitly not verified here

- **NASA data download and measured-data run:** external archive request returned HTTP 403.
  The original MATLAB parser was checked against a genuine MATLAB-format fixture, not
  the four original source files. Do the real-data extraction audit before drawing conclusions.
- **XGBoost, PyTorch LSTM and SHAP execution:** those packages were unavailable and the
  environment's restricted package access prevented installation. Their actual code is
  supplied; it is not a surrogate or a skipped implementation. Tests for them are present
  and run when full dependencies are installed. No performance claim is made for them here.
- **Jupyter kernel/UI integration:** nbclient, ipykernel and Jupyter were unavailable.
  Plain Python notebook cells were executed; a real kernel launch was not tested here.
- **Windows VS Code UI:** configuration and Windows commands are supplied; GUI launch was
  not performed in this Linux environment.
- Optional backend requirements use compatibility ranges; record locally resolved versions
  and investigate API issues rather than interpreting this document as full certification.

## Reproduce and close the remaining checks locally

```bash
python -m pip install -r requirements-full.txt
python -m unittest discover -s tests -v
python -m battery_rul demo --full-models --output outputs/local_full_smoke
python -m battery_rul download
python -m battery_rul extract
python -m battery_rul audit --data data/processed/nasa_cycles.csv
python -m battery_rul run --data data/processed/nasa_cycles.csv --output outputs/local_nasa
```

Then run the notebook in your selected Jupyter kernel. Synthetic test success is evidence
of executable software, not validation of NASA performance or a guarantee of a grade.

The supplied package artifacts use importable package classes. Standalone notebook
artifacts use notebook-defined classes: reload those in a notebook after running its
class-definition cells. Use package-created artifacts for the CLI prediction command.
