# Methodology and validity decisions

## Task and time of prediction

For cell b, let E_b be the first observed discharge cycle with measured capacity at or
below 1.4 Ah. Define RUL(b,t) = E_b - t for t ≤ E_b. Later cycles are excluded even if
capacity temporarily recovers. EOL is defined from raw measurements, not a smoothed
future trajectory. Missing capacity does not remove/renumber the discharge operation.
This is an observed-discharge-cycle target, not calendar time or equivalent full cycles.

Prediction occurs **after cycle t completes**. Current capacity, voltage summaries,
current summaries and discharge duration are consequently available. A forecast at the
start of that discharge would require lagging these features; the current evaluation
does not make that claim. Ground-truth EOL looks forward only for offline target creation.
No test-cell lifetime, final capacity, normalized lifetime fraction or battery ID is a feature.

## Censoring and scope adjustment

A trajectory without an observed 1.4 Ah crossing has unknown exact EOL. It is right-censored.
The labelled regression dataset therefore contains only observed events. Every requested
cell is audited and visualized, but only labelled cells receive RUL error scores. This is
an intentional scientifically necessary qualification to the proposal's four-cell LOBO
wording. A threshold crossing missing between sparse measurements is not inferred.

The results are conditional on observed-EOL cells; censoring can introduce selection bias.
A survival-analysis extension would be appropriate for training on censoring, but is not
implemented or claimed. Do not fabricate an endpoint for an incomplete cell. An alternate
1.5 Ah threshold is a **different endpoint** and must be predeclared and reported separately.

## Features and temporal context

Original MATLAB operation order aligns each discharge to the most recent preceding
charge and EIS observations. Leading EIS values remain missing; there is no backward fill
from future tests. EIS age helps represent measurement staleness. Operation order is
assumed to be chronological, as in the source structure; edited or reordered files are unsupported.

Windows contain cycles t-w+1 through t for w in {10,20,30}. All experiments use endpoints
starting at max(w)=30, so changing the history length does not secretly change test cases.
Imputation/scaling are fitted to training-window timesteps only. Overlapping windows
therefore give interior timesteps more preprocessing weight; this is an intentional
window-based fit, not use of held-out observations. All-missing and near-constant original
signals are removed using only the training fold. No bidirectional smoothing is used.

Trees and Ridge consume last, mean, standard deviation, and OLS slope of each retained
standardized signal. LSTM consumes the complete standardized sequence. This compares
sensible model-specific representations of identical historical observations, not
identical hypothesis classes. Full features include capacity and durations. Reduced
features exclude capacity plus discharge/charge durations, which can proxy capacity;
other sensors may still correlate with capacity. The capacity-only control is optional.

## Baselines and learning algorithms

- Cycle reference: mean training-cell EOL minus current cycle, clipped at zero. Mean
  lifetime is computed once per training cell so long cells do not dominate it.
- Random Forest: bootstrap ensemble; depth/minimum-leaf grid selected on inner cells.
- XGBoost: squared-error boosting, conservative depth and learning rate, deterministic
  full row/column sampling and CPU histogram trees.
- LSTM: one causal, unidirectional LSTM layer; final hidden sequence output feeds a
  small dense regression head. Training-only target standardization, Adam, weight
  decay and gradient clipping. Epoch/hidden-size choices are selected on inner cells.
  Fixed selected epochs are used when refitting; the outer test never stops training.
- Ridge: optional regularized linear reference on the same summaries as the trees.

`models.py` declares the full grids. Fast demo mode uses one candidate and four LSTM
epochs; its purpose is software validation, not meaningful architecture comparison.

## Nested battery-level evaluation

1. Hold out one observed-EOL cell completely as the outer test cell.
2. On the remaining cells, rotate one entire cell as inner validation.
3. Refit preprocessing for every inner training split. Score candidate hyperparameters
   by mean inner-cell RMSE, giving validation cells equal weight.
4. Refit the chosen candidate and preprocessing on all outer-training cells.
5. Score the untouched outer cell; repeat for each event-observed cell.

Model-specific parameters are selected within each fixed window/feature experiment.
For explanation, a separate tree selection compares RF/XGBoost/window/feature combinations
using **only** their inner validation score; its outer error is saved separately.
This gives an honest outer estimate of that tree-selection procedure. The lowest entry
in the post-hoc full summary is descriptive; it is not an unbiased estimate of selecting
that winner and deploying it. With three labelled cells, each inner fit can contain just
one cell; this limitation is substantial and must be discussed.

## Metrics and interpretation

MAE = mean absolute residual. RMSE = square root of mean squared residual.
R² = 1 - residual sum of squares / total sum of squares. It can be negative when the
held-out cell generalizes poorly. Predictions are clipped only at zero, not to an oracle
maximum life. Positive bias means overestimating remaining life.

Compute each metric per held-out cell and seed; average seeds within each cell, then
macro-average cells. Between-cell RMSE standard deviation is descriptive heterogeneity,
not a confidence interval. Do not treat hundreds of overlapping windows as independent
samples for a significance test. With three/four batteries, population uncertainty is
large. Extra seeds measure algorithmic variation, not unseen-population diversity.

SHAP uses a background from outer-training windows and explains a subsample of held-out
windows. Contributions are in RUL cycles for the raw tree prediction before clipping.
Feature values are standardized; names retain original sensor and summary identity.
Correlated capacity, duration and voltage features may divide attribution. SHAP is not
causal proof and is not used to choose features from the test data.

## Useful extensions after the main result

Run three seeds; add the capacity-only control and Ridge; report near-EOL overestimation;
compare feature missingness by cell; inspect unstable EOL crossings. Then consider
external cells, survival methods for censoring, uncertainty calibration on more held-out
cells, or beginning-of-cycle prediction. These last four are future work, not features
claimed by this implementation.
