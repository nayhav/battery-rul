"""Comparable regression models. Optional packages fail explicitly when requested."""
import copy
import random
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from .features import summarize_windows


class CycleBaseline:
    """Mean training EOL minus current cycle; no test-cell lifetime information."""
    def fit(self, cycles, y, groups):
        # Equal weight per battery, regardless of how many windows it contributes.
        self.mean_life = np.mean([np.median((cycles+y)[groups == c]) for c in np.unique(groups)])
        return self

    def predict(self, cycles):
        return np.maximum(0, self.mean_life - cycles)


class LSTMRegressor:
    """Small CPU PyTorch LSTM with fixed epochs selected via inner cell validation.

    No validation_split on shuffled windows; outer held-out cells never control
    training. Target standardization is learned from training targets only.
    """
    def __init__(self, seed=42, hidden_size=32, epochs=80, lr=.003):
        self.seed, self.hidden_size, self.epochs, self.lr = seed, hidden_size, epochs, lr

    def fit(self, x, y):
        try:
            import torch
        except ImportError as exc:
            raise ImportError('LSTM requires torch. Install requirements-full.txt.') from exc
        random.seed(self.seed)
        np.random.seed(self.seed)
        torch.manual_seed(self.seed)
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
        # A standard LSTM, not a feed-forward surrogate.
        self.net = torch.nn.ModuleDict({
            'lstm': torch.nn.LSTM(x.shape[2], self.hidden_size, batch_first=True),
            'head': torch.nn.Sequential(torch.nn.Linear(self.hidden_size, 16),
                                       torch.nn.ReLU(), torch.nn.Linear(16, 1))})
        self.mean_, self.scale_ = float(np.mean(y)), max(float(np.std(y)), 1.0)
        tx = torch.as_tensor(x, dtype=torch.float32)
        ty = torch.as_tensor((y-self.mean_)/self.scale_, dtype=torch.float32)
        optimizer = torch.optim.Adam(self.net.parameters(), lr=self.lr, weight_decay=1e-4)
        generator = torch.Generator().manual_seed(self.seed)
        self.loss_history = []
        self.net.train()
        for _ in range(self.epochs):
            total = 0.0
            for ix in torch.randperm(len(tx), generator=generator).split(32):
                optimizer.zero_grad()
                sequence, _ = self.net['lstm'](tx[ix])
                pred = self.net['head'](sequence[:, -1]).squeeze(-1)
                loss = torch.nn.functional.mse_loss(pred, ty[ix])
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
                optimizer.step()
                total += float(loss.detach()) * len(ix)
            self.loss_history.append(total / len(tx))
        return self

    def predict(self, x):
        import torch
        self.net.eval()
        with torch.no_grad():
            sequence, _ = self.net['lstm'](torch.as_tensor(x, dtype=torch.float32))
            result = self.net['head'](sequence[:, -1]).squeeze(-1).numpy()
        return result*self.scale_ + self.mean_


def candidates(name, fast=False):
    """Small declared grids; inner leave-one-cell-out chooses the parameters."""
    grids = {
        'rf': [dict(n_estimators=80 if fast else 250, max_depth=5, min_samples_leaf=3),
               dict(n_estimators=80 if fast else 250, max_depth=None, min_samples_leaf=5)],
        'xgb': [dict(n_estimators=80 if fast else 250, max_depth=2, learning_rate=.04),
                dict(n_estimators=80 if fast else 250, max_depth=3, learning_rate=.04)],
        'lstm': [dict(hidden_size=16, epochs=4 if fast else 60, lr=.003),
                 dict(hidden_size=32, epochs=4 if fast else 100, lr=.003)],
        'ridge': [dict(alpha=1.0), dict(alpha=10.0)]}
    if name not in grids:
        raise ValueError(f'Unknown model {name}')
    return grids[name][:1] if fast else grids[name]


def create_model(name, params, seed):
    if name == 'rf':
        return RandomForestRegressor(random_state=seed, n_jobs=1, **params)
    if name == 'ridge':
        return Ridge(**params)
    if name == 'xgb':
        try:
            from xgboost import XGBRegressor
        except ImportError as exc:
            raise ImportError('XGBoost requires xgboost. Install requirements-full.txt.') from exc
        return XGBRegressor(objective='reg:squarederror', random_state=seed, n_jobs=1,
                            tree_method='hist', subsample=1, colsample_bytree=1, **params)
    if name == 'lstm':
        return LSTMRegressor(seed=seed, **params)
    raise ValueError(name)


def model_input(name, x):
    return x if name == 'lstm' else summarize_windows(x)
