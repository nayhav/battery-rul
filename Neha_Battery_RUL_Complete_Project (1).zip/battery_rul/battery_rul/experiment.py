"""Nested battery-level experiments, held-out explanations and reusable artifacts."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform
import time
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from .data import FEATURE_SETS, validate_frame, construct_targets
from .features import WindowPreprocessor, make_windows, summarize_windows, summary_names
from .models import CycleBaseline, candidates, create_model, model_input


def scores(y, prediction):
    return {'mae': float(mean_absolute_error(y, prediction)),
            'rmse': float(np.sqrt(mean_squared_error(y, prediction))),
            'r2': float(r2_score(y, prediction)) if len(y)>1 and np.var(y)>0 else None,
            'bias': float(np.mean(prediction-y)),
            'n': len(y)}


def json_write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str), encoding='utf-8')


def tune_model(name, x, metadata, seed, fast):
    """Tune solely on outer-training batteries using inner leave-one-cell-out."""
    groups = metadata.battery_id.to_numpy()
    y = metadata.rul.to_numpy()
    records = []
    for params in candidates(name, fast):
        errors = []
        for validation_cell in sorted(set(groups)):
            train, valid = groups != validation_cell, groups == validation_cell
            pre = WindowPreprocessor().fit(x[train])
            xt, xv = pre.transform(x[train]), pre.transform(x[valid])
            model = create_model(name, params, seed).fit(model_input(name, xt), y[train])
            pred = np.maximum(0, model.predict(model_input(name, xv)))
            errors.append(float(np.sqrt(mean_squared_error(y[valid], pred))))
        records.append({'params': params, 'mean_inner_cell_rmse': float(np.mean(errors)),
                        'inner_cell_rmse': errors})
    best = min(records, key=lambda r: r['mean_inner_cell_rmse'])
    return best['params'], best['mean_inner_cell_rmse'], records


def explain_tree(bundle, x_train, x_test, outdir):
    """Tree SHAP with training-only background and held-out observations.

    Explanation applies to raw tree outputs before nonnegative clipping. SHAP is
    an association, not proof that changing a sensor causes a lifetime change.
    """
    try:
        import shap
    except ImportError as exc:
        raise ImportError('SHAP requested; install requirements-full.txt or explicitly use --no-shap') from exc
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    pre, model = bundle['preprocessor'], bundle['model']
    train = summarize_windows(pre.transform(x_train))
    test = summarize_windows(pre.transform(x_test))
    # Deterministic evenly spread samples cover early and late test life.
    bg = train[np.linspace(0, len(train)-1, min(80, len(train)), dtype=int)]
    chosen = np.linspace(0, len(test)-1, min(80, len(test)), dtype=int)
    test = test[chosen]
    names = summary_names(bundle['features'], pre.keep)
    explainer = shap.TreeExplainer(model, data=bg, feature_perturbation='interventional')
    explanation = explainer(test, check_additivity=True)
    pd.DataFrame(explanation.values, columns=names).to_csv(outdir/'shap_values.csv', index=False)
    pd.DataFrame(test, columns=names).to_csv(outdir/'explained_features_scaled.csv', index=False)
    importance = pd.DataFrame({'feature': names, 'mean_abs_shap': np.abs(explanation.values).mean(axis=0)})
    importance.sort_values('mean_abs_shap', ascending=False).to_csv(outdir/'importance.csv', index=False)
    shap.summary_plot(explanation.values, test, feature_names=names, show=False, max_display=15)
    plt.tight_layout()
    plt.savefig(outdir/'shap_summary.png', dpi=160, bbox_inches='tight')
    plt.close()
    # Keep baseline values so a single prediction can be reconstructed exactly.
    json_write(outdir/'explanation.json', {'test_window_indices': chosen.tolist(),
        'base_values': np.asarray(explanation.base_values).tolist(),
        'model': bundle['name'], 'features_are_standardized': True,
        'meaning': 'Contributions to raw predicted RUL in cycles, before clipping. Non-causal.'})


def run_experiments(frame, output_dir, windows=(10,20,30), feature_sets=('full','reduced'),
                    models=('rf','xgb','lstm'), seeds=(42,), threshold=1.4,
                    fast=False, do_shap=True):
    """A fresh run directory prevents stale or mixed-source output files.

    A censored cell is retained in the audit, never converted to a false event.
    Three event-observed cells are needed for nested train/validation/test splits.
    """
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f'{output} is not empty; choose a new output directory')
    windows = tuple(sorted(set(int(w) for w in windows)))
    if not windows or min(windows)<2 or not seeds or not models:
        raise ValueError('Provide windows >= 2, at least one model, and at least one seed')
    for feature_set in feature_sets:
        if feature_set not in FEATURE_SETS:
            raise ValueError(f'Unknown feature set {feature_set}')
    # Check all requested dependencies before beginning an expensive experiment.
    for name in models:
        create_model(name, candidates(name, fast)[0], int(seeds[0]))
        if name == 'lstm':
            import torch
    if do_shap:
        import shap
    frame = validate_frame(frame)
    labelled, audit = construct_targets(frame, threshold)
    cells = sorted(labelled.battery_id.unique())
    if len(cells)<3:
        raise ValueError(f'Only {len(cells)} cells reach {threshold} Ah. Need >=3 for nested evaluation; inspect targets.')
    for cell, group in labelled.groupby('battery_id'):
        if len(group)<max(windows)+1:
            raise ValueError(f'{cell}: too short for common endpoints at cycle {max(windows)}')
    output.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output/'input_cycles.csv', index=False)
    audit.to_csv(output/'eol_audit.csv', index=False)
    labelled.to_csv(output/'labelled_cycles.csv', index=False)
    frame[FEATURE_SETS['full']].isna().mean().rename('missing_fraction').to_csv(output/'missingness.csv')
    configuration = dict(windows=windows, feature_sets=feature_sets, models=models, seeds=seeds,
                         threshold_ah=threshold, fast=fast, shap=do_shap,
                         common_first_endpoint=max(windows), test_cells=cells,
                         source=sorted(frame.source.unique().tolist()) if 'source' in frame else ['USER_SUPPLIED'],
                         protocol='nested leave-one-observed-EOL-battery-out; inner mean cell RMSE',
                         input_sha256=hashlib.sha256((output/'input_cycles.csv').read_bytes()).hexdigest())
    versions = {'python': platform.python_version()}
    for package in ('numpy','pandas','scipy','scikit-learn','matplotlib','joblib','xgboost','torch','shap'):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = 'not installed'
    json_write(output/'config.json', configuration)
    json_write(output/'environment.json', versions)
    metrics, predictions, tuning = [], [], []
    start = time.time()
    # A selected tree per outer fold is chosen using INNER validation, never test RMSE.
    best_tree = {}
    for window in windows:
        for feature_set in feature_sets:
            features = FEATURE_SETS[feature_set]
            x, meta = make_windows(labelled, features, window, min_endpoint=max(windows))
            for seed in seeds:
                for test_cell in cells:
                    train = (meta.battery_id != test_cell).to_numpy()
                    test = ~train
                    train_meta, test_meta = meta.loc[train].reset_index(drop=True), meta.loc[test].reset_index(drop=True)
                    ytrain, ytest = train_meta.rul.to_numpy(), test_meta.rul.to_numpy()
                    # The baseline is repeated for each ablation to guarantee paired endpoints.
                    baseline = CycleBaseline().fit(train_meta.cycle.to_numpy(), ytrain, train_meta.battery_id.to_numpy())
                    for name in ('cycle_baseline', *models):
                        base = dict(window=window, feature_set=feature_set, seed=int(seed), test_battery=test_cell, model=name)
                        if name == 'cycle_baseline':
                            pred = baseline.predict(test_meta.cycle.to_numpy())
                        else:
                            params, inner_score, records = tune_model(name, x[train], train_meta, int(seed), fast)
                            tuning.append({**base, 'chosen_params': params, 'inner_rmse': inner_score,
                                           'train_cells': sorted(train_meta.battery_id.unique().tolist()), 'candidates': records})
                            pre = WindowPreprocessor().fit(x[train])
                            model = create_model(name, params, int(seed)).fit(model_input(name, pre.transform(x[train])), ytrain)
                            raw = model.predict(model_input(name, pre.transform(x[test])))
                            pred = np.maximum(0, raw)
                            bundle = dict(name=name, model=model, preprocessor=pre, features=features,
                                          window=window, threshold=threshold, params=params,
                                          train_cells=sorted(train_meta.battery_id.unique().tolist()),
                                          test_cell=test_cell, seed=int(seed), source=configuration['source'],
                                          prediction_time='after current discharge', schema_version=1)
                            location = output/'models'/f'{name}_{feature_set}_w{window}_seed{seed}_{test_cell}.joblib'
                            location.parent.mkdir(exist_ok=True)
                            joblib.dump(bundle, location)
                            if name == 'lstm':
                                json_write(location.with_suffix('.loss.json'), model.loss_history)
                            key = (int(seed), test_cell)
                            if name in ('rf','xgb') and (key not in best_tree or inner_score < best_tree[key]['score']):
                                best_tree[key] = dict(score=inner_score, path=location, x_train=x[train], x_test=x[test],
                                                      test_meta=test_meta, selection=base)
                        metrics.append({**base, **scores(ytest, pred)})
                        predictions.extend([{**base, 'cycle': int(c), 'actual_rul': float(y),
                                             'predicted_rul': float(p), 'error': float(p-y)}
                                            for c,y,p in zip(test_meta.cycle, ytest, pred)])
                    print(f'Completed {test_cell}, window={window}, features={feature_set}, seed={seed}', flush=True)
    metric_frame = pd.DataFrame(metrics)
    prediction_frame = pd.DataFrame(predictions)
    metric_frame.to_csv(output/'metrics_by_cell.csv', index=False)
    prediction_frame.to_csv(output/'predictions.csv', index=False)
    # First average seeds within each cell; then macro-average cells equally.
    keys = ['model','feature_set','window']
    per_cell = metric_frame.groupby(keys+['test_battery'])[['mae','rmse','r2','bias']].mean().reset_index()
    summary = per_cell.groupby(keys).agg(mae=('mae','mean'), rmse=('rmse','mean'),
                rmse_between_cell_sd=('rmse','std'), r2=('r2','mean'), cells=('test_battery','nunique')).reset_index()
    summary.to_csv(output/'summary.csv', index=False)
    json_write(output/'tuning.json', tuning)
    selection_records = []
    for (seed, cell), selected in best_tree.items():
        selected_bundle = joblib.load(selected['path'])
        selected_pred = np.maximum(0, selected_bundle['model'].predict(
            summarize_windows(selected_bundle['preprocessor'].transform(selected['x_test']))))
        selection_records.append({**selected['selection'], 'inner_rmse': selected['score'],
            'artifact': str(selected['path'].relative_to(output)),
            **scores(selected['test_meta'].rul.to_numpy(), selected_pred)})
        if do_shap:
            explain_tree(selected_bundle, selected['x_train'], selected['x_test'], output/'shap'/f'{cell}_seed{seed}')
    pd.DataFrame(selection_records).to_csv(output/'inner_selected_tree_metrics.csv', index=False)
    from .reporting import build_report
    build_report(frame, audit, metric_frame, prediction_frame, summary, output, configuration)
    json_write(output/'run_status.json', {'status':'complete', 'elapsed_seconds':round(time.time()-start,2),
        'shap': 'completed for inner-selected trees' if do_shap else 'explicitly disabled'})
    return summary


def predict_history(artifact_path, history):
    """Predict from latest unlabelled window; no EOL or future capacity required.

    Only load artifacts you trust: joblib/pickle can execute code during loading.
    """
    bundle = joblib.load(artifact_path)
    history = validate_frame(history)
    if history.battery_id.nunique() != 1:
        raise ValueError('Provide exactly one battery history')
    window = bundle['window']
    if len(history)<window:
        raise ValueError(f'At least {window} cycles are required')
    last = history.iloc[-window:]
    x = last[bundle['features']].to_numpy(dtype=float)[None, :, :]
    predicted = float(bundle['model'].predict(model_input(bundle['name'], bundle['preprocessor'].transform(x)))[0])
    already_eol = bool((history.capacity_ah <= bundle['threshold']).any())
    return {'battery_id': history.battery_id.iloc[-1], 'cycle': int(history.cycle.iloc[-1]),
            'predicted_rul_cycles': 0.0 if already_eol else max(0.0, predicted),
            'status': 'EOL already observed' if already_eol else 'model forecast',
            'model': bundle['name'], 'training_source': bundle['source'],
            'seen_training_cell': bool(history.battery_id.iloc[0] in bundle['train_cells'])}
