"""Past-only sequence construction and fold-local preprocessing."""
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


class WindowPreprocessor:
    """Fit on training sequences only; drop missing/near-constant signals.

    The same transform applies to trees and LSTM. Median imputation is learned
    inside each split. Trailing windows overlap within a cell, never across cells.
    """
    def fit(self, x):
        flat = x.reshape(-1, x.shape[-1])
        finite_count = np.isfinite(flat).sum(axis=0)
        variance = np.array([np.var(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in flat.T])
        self.keep = (finite_count > 0) & (variance > 1e-12)
        if not self.keep.any():
            raise ValueError('No varying observed training features remain')
        self.imputer = SimpleImputer(strategy='median')
        filled = self.imputer.fit_transform(flat[:, self.keep])
        self.scaler = StandardScaler().fit(filled)
        return self

    def transform(self, x):
        shape = x.shape
        selected = x.reshape(-1, shape[-1])[:, self.keep]
        clean = self.scaler.transform(self.imputer.transform(selected))
        return clean.reshape(shape[0], shape[1], int(self.keep.sum())).astype(np.float32)


def make_windows(frame, features, window, min_endpoint=1):
    """Features cover cycles [t-window+1, t], target is RUL after cycle t.

    min_endpoint=max(all tested windows) gives every history ablation identical
    evaluation endpoints, eliminating an easy source of unfair comparisons.
    Also works on unlabelled deployment histories (rul becomes NaN).
    """
    if window < 2:
        raise ValueError('window must be >= 2')
    windows, metadata = [], []
    for cell, group in frame.groupby('battery_id', sort=True):
        group = group.sort_values('cycle')
        values = group[features].to_numpy(dtype=float)
        for end in range(window-1, len(group)):
            row = group.iloc[end]
            if row.cycle < min_endpoint:
                continue
            windows.append(values[end-window+1:end+1])
            metadata.append(dict(battery_id=cell, cycle=int(row.cycle),
                                 rul=float(row.get('rul', np.nan))))
    if not windows:
        raise ValueError(f'No usable windows of length {window}; check trajectory lengths')
    return np.stack(windows), pd.DataFrame(metadata)


def summarize_windows(x):
    """Four interpretable features per signal: last, mean, std, and OLS slope."""
    time = np.arange(x.shape[1], dtype=float)
    time -= time.mean()
    slope = np.einsum('ntf,t->nf', x, time) / (time @ time)
    return np.concatenate([x[:, -1], x.mean(axis=1), x.std(axis=1), slope], axis=1)


def summary_names(features, keep):
    return [f'{name}__{stat}' for stat in ('last', 'mean', 'std', 'slope')
            for name, included in zip(features, keep) if included]
