"""Download the archive linked from NASA; extract only the four required cells."""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import shutil
import urllib.request
import zipfile
from .data import CELLS

NASA_ARCHIVE = 'https://phm-datasets.s3.amazonaws.com/NASA/5.+Battery+Data+Set.zip'


def download_nasa(destination, archive=None):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    if all((destination/(cell+'.mat')).is_file() for cell in CELLS):
        print('All four MATLAB files already exist; reusing them.')
        return
    archive_path = Path(archive) if archive else destination/'nasa_batteries.zip'
    if not archive_path.exists():
        temporary = archive_path.with_suffix('.part')
        try:
            print('Downloading official NASA-linked archive. It may be large.', flush=True)
            request = urllib.request.Request(NASA_ARCHIVE, headers={'User-Agent':'BatteryRUL-Education/1.0'})
            with urllib.request.urlopen(request, timeout=120) as response, temporary.open('wb') as stream:
                shutil.copyfileobj(response, stream)
            temporary.replace(archive_path)
        except Exception as exc:
            temporary.unlink(missing_ok=True)
            raise RuntimeError('Download failed. Open the NASA repository link in README, download the battery archive, '
                               'then use: python -m battery_rul download --archive PATH_TO_ZIP') from exc
    found = set()
    def extract_selected(zf, depth=0):
        if depth>3:
            raise ValueError('Unexpected archive nesting')
        for item in zf.infolist():
            basename = Path(item.filename).name
            if basename in {cell+'.mat' for cell in CELLS}:
                if basename in found:
                    raise ValueError(f'Duplicate cell file in archive: {basename}')
                if item.file_size>200_000_000:
                    raise ValueError('Unexpectedly large MATLAB file')
                # Basename-only extraction prevents archive path traversal.
                with zf.open(item) as source, (destination/basename).open('wb') as target:
                    shutil.copyfileobj(source,target)
                found.add(basename)
            elif basename.lower().endswith('.zip'):
                if item.file_size>600_000_000:
                    raise ValueError('Unexpectedly large nested archive')
                with zipfile.ZipFile(BytesIO(zf.read(item))) as child:
                    extract_selected(child, depth+1)
    with zipfile.ZipFile(archive_path) as zf:
        extract_selected(zf)
    missing = {cell+'.mat' for cell in CELLS}-found
    if missing:
        raise ValueError(f'Archive did not contain: {sorted(missing)}')
    # Stream the hash so a large archive does not require another large allocation.
    digest = hashlib.sha256()
    with archive_path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            digest.update(chunk)
    (destination/'download_manifest.json').write_text(json.dumps({
        'url':NASA_ARCHIVE, 'archive_sha256':digest.hexdigest(),
        'files':sorted(found)},indent=2),encoding='utf-8')
    print(f'Extracted {len(found)} cells to {destination}')
