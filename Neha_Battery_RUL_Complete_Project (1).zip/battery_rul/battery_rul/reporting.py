"""Save publication-friendly figures and a portable HTML experiment report."""
from pathlib import Path
from html import escape
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def build_report(frame, audit, metrics, predictions, summary, output, config):
    output = Path(output)
    figures = output/'figures'
    figures.mkdir(exist_ok=True)
    plt.rcParams.update({'figure.dpi':110, 'axes.spines.top':False,
                         'axes.spines.right':False, 'font.size':10})
    fig, ax = plt.subplots(figsize=(9,4))
    for cell, group in frame.groupby('battery_id'):
        ax.plot(group.cycle, group.capacity_ah, label=cell, linewidth=1.8)
    ax.axhline(config['threshold_ah'], color='#b91c1c', ls='--', label='EOL threshold')
    ax.set(xlabel='Completed discharge cycle', ylabel='Discharge capacity (Ah)', title='Capacity trajectories and observed EOL')
    ax.legend(ncol=3)
    fig.tight_layout(); fig.savefig(figures/'capacity.png'); plt.close(fig)
    # One predeclared slice for readable plots, NOT a claim of best test model.
    window = 20 if 20 in config['windows'] else config['windows'][0]
    subset = summary[(summary.window==window)&(summary.feature_set==config['feature_sets'][0])]
    fig, ax = plt.subplots(figsize=(9,4))
    ax.bar(subset.model, subset.rmse, color='#0f766e')
    ax.set(ylabel='Macro cell RMSE (cycles)', title=f'Predeclared {window}-cycle / {config["feature_sets"][0]} comparison')
    fig.tight_layout(); fig.savefig(figures/'model_comparison.png'); plt.close(fig)
    subset = predictions[(predictions.window==window)&(predictions.feature_set==config['feature_sets'][0])&
                         (predictions.seed==config['seeds'][0])]
    cells = sorted(subset.test_battery.unique())
    fig, axes = plt.subplots(len(cells), 2, figsize=(12,3.1*len(cells)), squeeze=False)
    for row, cell in enumerate(cells):
        part = subset[subset.test_battery==cell]
        truth = part.drop_duplicates('cycle').sort_values('cycle')
        axes[row,0].plot(truth.cycle, truth.actual_rul, color='black', ls='--', label='Observed RUL')
        for model, group in part.groupby('model'):
            axes[row,0].plot(group.cycle, group.predicted_rul, label=model, alpha=.85)
            axes[row,1].plot(group.cycle, group.error, label=model, alpha=.85)
        axes[row,0].set(title=f'Unseen {cell}', ylabel='RUL (cycles)', xlabel='Cycle')
        axes[row,1].set(title=f'{cell}: prediction minus truth', ylabel='Error (cycles)', xlabel='Cycle')
        axes[row,1].axhline(0, color='black', lw=.8)
        axes[row,0].legend(fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(figures/'predictions.png'); plt.close(fig)
    fig, ax = plt.subplots(figsize=(9,4))
    for (model, features), group in summary.groupby(['model','feature_set']):
        ax.plot(group.window, group.rmse, marker='o', label=f'{model} / {features}')
    ax.set(xlabel='History window (cycles)', ylabel='Macro cell RMSE (cycles)', title='Window and health-indicator ablations')
    ax.set_xticks(config['windows']); ax.legend(fontsize=8, ncol=2)
    fig.tight_layout(); fig.savefig(figures/'ablations.png'); plt.close(fig)
    # Early/late bins use true RUL only for retrospective analysis, never as inputs.
    diagnostics = predictions.assign(life_stage=pd.cut(predictions.actual_rul,
        bins=[-1,20,60,np.inf], labels=['Near EOL: 0-20','Middle: 21-60','Early: >60']))
    stage = diagnostics.groupby(['model','feature_set','window','test_battery','seed','life_stage'], observed=True).error.agg(
        mae=lambda e: np.abs(e).mean(), bias='mean', n='size').reset_index()
    stage.to_csv(output/'errors_by_life_stage.csv', index=False)
    source = ', '.join(config['source'])
    synthetic = 'SYNTHETIC' in source
    banner = ('SYNTHETIC DEMONSTRATION — validates software, not NASA performance.' if synthetic else
              'Measured-data experiment — interpret results within the evaluated cells and protocol.')
    html = f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Battery RUL | Experiment report</title><style>
body{{font:16px/1.6 system-ui,sans-serif;margin:0;background:#f1f5f9;color:#172033}}
main{{max-width:1100px;margin:auto;padding:36px}}h1{{font-size:36px;line-height:1.2}}h2{{margin-top:36px}}
.card{{background:white;padding:24px;border-radius:14px;margin:20px 0;overflow:auto}}
.banner{{background:#fef3c7;border-left:5px solid #d97706;padding:18px}}table{{border-collapse:collapse;width:100%;font-size:13px}}
th,td{{padding:9px;text-align:left;border-bottom:1px solid #e2e8f0}}img{{width:100%;height:auto}}
small{{color:#475569}}a{{color:#0f766e}}</style><main>
<small>NEHA VARADHARAJAN · 240962214 · ML MINI PROJECT</small>
<h1>Lithium-ion battery<br>remaining useful life prediction</h1>
<p class="banner">{escape(banner)}</p>
<p>Source: {escape(source)}. Prediction time: after a completed discharge.
EOL: first observed capacity ≤ {config['threshold_ah']} Ah. Target: EOL cycle minus current cycle.</p>
<div class="card"><h2>Data and censoring audit</h2>{audit.to_html(index=False, float_format=lambda v:f'{v:.3f}')}
<p>Cells without an observed threshold crossing are excluded from supervised RUL scoring.
Their last recorded cycle is not assumed to be end of life.</p><img src="figures/capacity.png" alt="Capacity trajectories"></div>
<div class="card"><h2>Evaluation protocol</h2><p>Outer battery holdout; inner leave-one-battery-out hyperparameter selection.
Training-only imputation, variance filtering, and scaling. Identical endpoints start at cycle {config['common_first_endpoint']}.
Seeds are averaged within each battery before macro-averaging across batteries. No shuffled cycle split.</p>
<p>{'FAST mode: one candidate per model; demonstration only.' if config['fast'] else 'Declared small hyperparameter grids selected on inner validation cells.'}
SHAP: {'enabled' if config['shap'] else 'explicitly disabled for this run'}.</p></div>
<div class="card"><h2>Experiment results</h2>{summary.round(3).to_html(index=False)}
<p>RMSE/MAE are in cycles; lower is better. R² may be negative on an unseen battery.
Between-cell SD is descriptive spread, not a confidence interval. Cells, not overlapping windows, are the independent units.</p>
<img src="figures/model_comparison.png" alt="Model comparison"><img src="figures/ablations.png" alt="History ablations"></div>
<div class="card"><h2>Held-out predictions and residuals</h2><img src="figures/predictions.png" alt="Predictions and residuals"></div>
<div class="card"><h2>Interpretation and limitations</h2><p>Use tuning.json and inner_selected_tree_metrics.csv to identify the tree selected without looking at outer test performance.
A post-hoc winner in summary.csv is descriptive, not an unbiased estimate for a newly selected model.
With only a few cells, this is a small benchmark; cycle observations are correlated and LSTM can overfit.
The reduced set removes capacity and discharge/charge duration, but other sensors can still proxy degradation or operating protocol.
Current-discharge capacity makes this an after-discharge forecast, not a beginning-of-cycle forecast.
SHAP describes associations among correlated features and does not establish causality.</p>
<p><a href="summary.csv">Summary CSV</a> · <a href="metrics_by_cell.csv">Per-cell metrics</a> ·
<a href="predictions.csv">All predictions</a> · <a href="config.json">Run configuration</a></p></div></main></html>'''
    (output/'report.html').write_text(html, encoding='utf-8')
