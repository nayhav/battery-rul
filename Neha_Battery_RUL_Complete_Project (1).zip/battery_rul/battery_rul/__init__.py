"""Battery RUL mini project: reproducible, cell-separated prognostics."""
__version__ = '1.0.0'
