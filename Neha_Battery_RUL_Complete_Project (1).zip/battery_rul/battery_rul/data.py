"""NASA MATLAB ingestion, causal health indicators, and auditable RUL labels."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.io import loadmat

CELLS = ('B0005', 'B0006', 'B0007', 'B0018')
FULL_FEATURES = ['cycle', 'capacity_ah', 'voltage_mean', 'voltage_std',
                 'voltage_min', 'current_mean', 'temperature_mean',
                 'temperature_max', 'duration_s', 'charge_duration_s',
                 'charge_voltage_mean', 're_ohm', 'rct_ohm', 'eis_age_cycles']
# Exclude both measured capacity AND discharge duration (a strong capacity proxy).
REDUCED_FEATURES = ['cycle', 'voltage_mean', 'voltage_std', 'voltage_min',
                    'current_mean', 'temperature_mean', 'temperature_max',
                    'charge_voltage_mean', 're_ohm', 'rct_ohm', 'eis_age_cycles']
FEATURE_SETS = {'full': FULL_FEATURES, 'reduced': REDUCED_FEATURES,
                'capacity_only': ['cycle', 'capacity_ah']}


def array_value(data, key):
    """Missing signals remain NaN; imaginary impedance parts are not discarded."""
    try:
        value = np.asarray(data.get(key, []))
        if np.iscomplexobj(value) and np.any(np.abs(value.imag) > 1e-10):
            return np.array([], dtype=float)
        value = value.real.astype(float).ravel()
        return value[np.isfinite(value)]
    except (TypeError, ValueError):
        return np.array([], dtype=float)


def scalar_value(data, key):
    value = array_value(data, key)
    return float(value[0]) if value.size else np.nan


def stat_value(data, key, operation):
    value = array_value(data, key)
    return float(operation(value)) if value.size else np.nan


def duration(data):
    value = array_value(data, 'Time')
    return float(value.max() - value.min()) if value.size > 1 else np.nan


def parse_mat(path):
    """One row per completed discharge. Past charge/EIS only, never backfilled.

    The source operation order is retained. A discharge count includes operations
    with missing capacity, avoiding a silent compression of the time axis.
    Prediction time is AFTER the current discharge; its measured capacity is legal.
    """
    path = Path(path)
    raw = loadmat(path, simplify_cells=True)
    key = path.stem
    if key not in raw or not isinstance(raw[key], dict) or 'cycle' not in raw[key]:
        raise ValueError(f'{path}: expected MATLAB struct {key}.cycle')
    operations = raw[key]['cycle']
    if isinstance(operations, dict):
        operations = [operations]
    rows, last_charge, last_eis = [], {}, {}
    discharge_count, eis_cycle = 0, None
    for operation_index, operation in enumerate(operations, start=1):
        kind, values = str(operation['type']).strip(), operation['data']
        if kind == 'charge':
            last_charge = values
        elif kind == 'impedance':
            last_eis, eis_cycle = values, discharge_count
        elif kind == 'discharge':
            discharge_count += 1
            rows.append(dict(
                battery_id=key, cycle=discharge_count, operation_index=operation_index,
                capacity_ah=scalar_value(values, 'Capacity'),
                voltage_mean=stat_value(values, 'Voltage_measured', np.mean),
                voltage_std=stat_value(values, 'Voltage_measured', np.std),
                voltage_min=stat_value(values, 'Voltage_measured', np.min),
                current_mean=stat_value(values, 'Current_measured', np.mean),
                temperature_mean=stat_value(values, 'Temperature_measured', np.mean),
                temperature_max=stat_value(values, 'Temperature_measured', np.max),
                duration_s=duration(values), charge_duration_s=duration(last_charge),
                charge_voltage_mean=stat_value(last_charge, 'Voltage_measured', np.mean),
                re_ohm=scalar_value(last_eis, 'Re'), rct_ohm=scalar_value(last_eis, 'Rct'),
                eis_age_cycles=(discharge_count - eis_cycle if eis_cycle is not None else np.nan),
                source='NASA'))
    if not rows:
        raise ValueError(f'{path}: no discharge operations found')
    return pd.DataFrame(rows)


def extract_nasa(raw_dir, output_path):
    """Require all four proposed cells. Save hashes for reproducible provenance."""
    paths = []
    for cell in CELLS:
        matches = list(Path(raw_dir).rglob(cell + '.mat'))
        if len(matches) != 1:
            raise ValueError(f'Expected exactly one {cell}.mat beneath {raw_dir}; found {len(matches)}')
        paths.append(matches[0])
    result = validate_frame(pd.concat([parse_mat(p) for p in paths], ignore_index=True))
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_path, index=False)
    provenance = {str(p.name): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    output_path.with_suffix('.provenance.json').write_text(json.dumps({
        'source': 'NASA Ames PCoE; Saha and Goebel (2007)',
        'landing_page': 'https://data.nasa.gov/dataset/li-ion-battery-aging-datasets',
        'mat_sha256': provenance, 'prediction_time': 'after completed discharge',
        'eis_alignment': 'most recent preceding operation only'}, indent=2), encoding='utf-8')
    return result


def validate_frame(frame):
    frame = frame.copy()
    required = {'battery_id', 'cycle', 'capacity_ah'}
    if not required.issubset(frame):
        raise ValueError(f'Missing required columns: {sorted(required - set(frame))}')
    if frame.empty or frame['battery_id'].isna().any():
        raise ValueError('Input must contain rows with non-null battery IDs')
    frame['battery_id'] = frame['battery_id'].astype(str)
    for col in FULL_FEATURES:
        if col not in frame:
            frame[col] = np.nan
        frame[col] = pd.to_numeric(frame[col], errors='raise')
    if not np.isfinite(frame['cycle']).all() or (frame['cycle'] < 1).any() or (frame['cycle'] % 1 != 0).any():
        raise ValueError('cycle must be a positive finite integer')
    if frame.duplicated(['battery_id', 'cycle']).any():
        raise ValueError('Duplicate battery/cycle rows')
    # Infinite sensor values mean unavailable measurements, not enormous signals.
    frame[FULL_FEATURES] = frame[FULL_FEATURES].replace([np.inf, -np.inf], np.nan)
    if ((frame.capacity_ah <= 0) | (frame.capacity_ah > 5)).any():
        raise ValueError('Capacity must be in Ah and between 0 and 5 when present')
    frame = frame.sort_values(['battery_id', 'cycle']).reset_index(drop=True)
    for cell, group in frame.groupby('battery_id'):
        if not np.array_equal(group.cycle.to_numpy(), np.arange(1, len(group) + 1)):
            raise ValueError(f'{cell}: cycles must be contiguous from 1; retain missing measurements as NaN rows')
    return frame


def construct_targets(frame, threshold=1.4):
    """First measured capacity <= threshold is EOL; censor non-crossing cells.

    Future capacity is used ONLY to construct retrospective ground truth. It is
    never fed to preprocessing or prediction. No final-record-as-EOL shortcut.
    """
    if not 0 < threshold < 5:
        raise ValueError('EOL threshold must be in (0, 5) Ah')
    frame = validate_frame(frame)
    labelled, audit = [], []
    for cell, group in frame.groupby('battery_id', sort=True):
        crossed = group.loc[group.capacity_ah <= threshold, 'cycle']
        eol = int(crossed.iloc[0]) if len(crossed) else None
        audit.append(dict(battery_id=cell, observed_cycles=len(group),
                          last_capacity_ah=group.capacity_ah.iloc[-1],
                          min_capacity_ah=group.capacity_ah.min(),
                          eol_cycle=eol, censored=eol is None,
                          missing_capacity=int(group.capacity_ah.isna().sum()),
                          excluded_after_eol=int((group.cycle > eol).sum()) if eol else 0))
        if eol is not None:
            group = group.loc[group.cycle <= eol].copy()
            group['rul'] = eol - group.cycle
            labelled.append(group)
    result = pd.concat(labelled, ignore_index=True) if labelled else frame.iloc[:0].assign(rul=pd.Series(dtype=float))
    return result, pd.DataFrame(audit)


def make_demo(seed=42):
    """Synthetic fixture, NOT NASA data or evidence of scientific performance.

    Four distinct trajectories and one right-censored cell exercise the actual
    pipeline. SIM IDs and a source field prevent confusion with measured cells.
    """
    rng, rows = np.random.default_rng(seed), []
    for j, (life, observed) in enumerate([(105, 125), (140, 160), (210, 145), (120, 140)]):
        start = 1.96 + rng.normal(0, .025)
        exponent = 1.0 + .15 * j
        for cycle in range(1, observed + 1):
            health_loss = (start - 1.4) * (cycle / life) ** exponent
            capacity = start - health_loss + rng.normal(0, .004)
            temperature = 26 + 5 * health_loss + .45 * j + rng.normal(0, .2)
            eis_age = (cycle - 1) % 8 + 1
            rows.append(dict(battery_id=f'SIM{j+1:02}', cycle=cycle,
                capacity_ah=capacity, voltage_mean=3.7 - .18 * health_loss + rng.normal(0, .01),
                voltage_std=.22 + .1 * health_loss + rng.normal(0, .004),
                voltage_min=2.7 + .04*j + rng.normal(0, .007),
                current_mean=-2 + rng.normal(0, .015), temperature_mean=temperature,
                temperature_max=temperature + 3 + rng.normal(0, .1),
                duration_s=capacity / 2 * 3600 + rng.normal(0, 15),
                charge_duration_s=4000 + 500*health_loss + rng.normal(0, 30),
                charge_voltage_mean=4.12 + .025*health_loss + rng.normal(0, .005),
                re_ohm=.04 + .06*health_loss if cycle > 8 else np.nan,
                rct_ohm=.05 + .08*health_loss if cycle > 8 else np.nan,
                eis_age_cycles=eis_age if cycle > 8 else np.nan, source='SYNTHETIC_DEMO'))
    return validate_frame(pd.DataFrame(rows))
