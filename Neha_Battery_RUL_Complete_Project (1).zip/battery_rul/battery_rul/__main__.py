"""CLI entry point. Run from the extracted project folder in VS Code."""
from pathlib import Path
import argparse
import json
import sys
import pandas as pd
from .data import extract_nasa, make_demo, construct_targets
from .experiment import run_experiments, predict_history


def main(argv=None):
    parser = argparse.ArgumentParser(description='NASA battery RUL mini project')
    sub = parser.add_subparsers(dest='command', required=True)
    download = sub.add_parser('download', help='Download NASA-linked archive or use a local ZIP')
    download.add_argument('--raw-dir',default='data/raw')
    download.add_argument('--archive')
    extract = sub.add_parser('extract', help='Convert original NASA MAT structs to causal cycle CSV')
    extract.add_argument('--raw-dir',default='data/raw')
    extract.add_argument('--output',default='data/processed/nasa_cycles.csv')
    demo = sub.add_parser('demo', help='Run clearly labelled synthetic demonstration')
    demo.add_argument('--output',default='outputs/demo')
    demo.add_argument('--full-models',action='store_true',help='Include XGBoost, LSTM and SHAP; requires full dependencies')
    run = sub.add_parser('run', help='Run nested battery holdout experiments')
    run.add_argument('--data',required=True)
    run.add_argument('--output',default='outputs/nasa_full')
    run.add_argument('--windows',type=int,nargs='+',default=[10,20,30])
    run.add_argument('--feature-sets',nargs='+',choices=['full','reduced','capacity_only'],default=['full','reduced'])
    run.add_argument('--models',nargs='+',choices=['rf','xgb','lstm','ridge'],default=['rf','xgb','lstm'])
    run.add_argument('--seeds',type=int,nargs='+',default=[42])
    run.add_argument('--threshold',type=float,default=1.4)
    run.add_argument('--fast',action='store_true')
    run.add_argument('--no-shap',action='store_true')
    audit = sub.add_parser('audit', help='Inspect EOL/censoring without model training')
    audit.add_argument('--data',required=True)
    audit.add_argument('--threshold',type=float,default=1.4)
    predict = sub.add_parser('predict',help='Predict using a trusted saved model and unlabelled history')
    predict.add_argument('--model',required=True)
    predict.add_argument('--history',required=True)
    args = parser.parse_args(argv)
    if args.command=='download':
        from .download import download_nasa
        download_nasa(args.raw_dir,args.archive)
    elif args.command=='extract':
        result=extract_nasa(args.raw_dir,args.output)
        print(f'Saved {len(result)} cycles to {args.output}')
    elif args.command=='demo':
        frame=make_demo()
        summary=run_experiments(frame,args.output,windows=(10,20,30),
            models=('rf','xgb','lstm') if args.full_models else ('rf','ridge'),
            fast=True,do_shap=args.full_models)
        print(summary.to_string(index=False))
        print(f'SYNTHETIC ONLY. Open {args.output}/report.html')
    elif args.command=='run':
        summary=run_experiments(pd.read_csv(args.data),args.output,windows=args.windows,
            feature_sets=args.feature_sets,models=args.models,seeds=args.seeds,
            threshold=args.threshold,fast=args.fast,do_shap=not args.no_shap)
        print(summary.to_string(index=False))
        print(f'Open {args.output}/report.html')
    elif args.command=='audit':
        _, audit_frame=construct_targets(pd.read_csv(args.data),args.threshold)
        print(audit_frame.to_string(index=False))
    elif args.command=='predict':
        print(json.dumps(predict_history(args.model,pd.read_csv(args.history)),indent=2))


if __name__=='__main__':
    try:
        main()
    except (ValueError,FileNotFoundError,FileExistsError,ImportError,RuntimeError) as error:
        print(f'ERROR: {error}',file=sys.stderr)
        sys.exit(2)
